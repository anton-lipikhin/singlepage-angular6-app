const
    env = process.env.NODE_ENV || 'development'

const common = {
    port: 4002,
    db: {
        driver: "pg",
        schema: "avr",
        host: 'localhost',
        database: 'portal',
        user: 'postgres',
        password: '123qweQWE',
        //ssl: true,
        port: 5432,
        max: 100, // max number of connection can be open to database
        idleTimeoutMillis: 3000 // how long a client is allowed to remain idle before being closed
        //connectionTimeoutMillis: 1000 // return an error after 1 second if connection could not be established
    }
}

const development = {
    env: 'dev'
}

const production = {
    env: 'prod'
}

const envs = {development, production}
const config = Object.assign(common, envs[env])

var module = module || {};
module.exports = config;