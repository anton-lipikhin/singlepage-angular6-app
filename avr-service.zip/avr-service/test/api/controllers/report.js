const
    should = require('should'),
    request = require('supertest'),
    http = require('http'),
    server = require('../../../app');

describe('controllers', ()=>{

    describe('report', ()=>{

        describe('GET /report', ()=>{

            it('should response with 2 rows if total rows >= 2', (done) => {

                const params = {
                    reportType: 1,
                    agreementId: 1,
                    startDateFrom: '2018-01-02',
                    startDateTo: '2018-01-05',
                    endDateFrom: '2018-02-01',
                    endDateTo: '2018-02-02',
                    limit: 2,
                    page: 0
                }

                request(server)
                    .get('/services/report')
                    .query(params)
                    .set('Accept', 'application/json')
                    .expect('Content-Type', /json/)
                    .expect(200)
                    .end((err, res) => {
                        should.not.exist(err);
                        res.body.should.be.an.Object();
                        res.body.data.should.be.an.Array();
                        done();
                    });
            });

        });

    });

});
