'use strict';

const
    db = require('../../libs/db'),
    config = require('../../config/config');

module.exports.report = function(req, res) {

    const
        reportType = req.swagger.params.reportType.value,
        agreementId = req.swagger.params.agreementId.value,
        startDateFrom = req.swagger.params.startDateFrom.value,
        startDateTo = req.swagger.params.startDateTo.value,
        endDateFrom = req.swagger.params.endDateFrom.value,
        endDateTo = req.swagger.params.endDateTo.value,
        limit = req.swagger.params.limit.value,
        page = req.swagger.params.page.value,
        // TODO: here should be at least 5 tables
        table = reportType == 1 ? 'vsk_agent_lock_comm_avr' : 'vsk_agent_lock_comm_avr'


    let query = `
        select *
        from ${config.db.schema}.${table}
        where
            policy_begin_date between '${startDateFrom}' and '${startDateTo}' and
            policy_end_date between '${endDateFrom}' and '${endDateTo}' and
            agent_agreement_id = ${agreementId}
        limit ${limit}
        offset ${page*limit}
    ;`;

    let countQuery = `select count(*) from ${config.db.schema}.vsk_agent_lock_comm_avr`;

    db.query(countQuery, countResult => {
        if(countResult.data.error){
            res.send(countResult.data.error);
            return;
        }
        let pageCount = countResult.data.rows[0].count
        db.query(query, result => {
            let data = result.data.error ? result.data.error : result.data.rows,
                response = {data: data, pageCount: pageCount};
            res.setHeader('Content-Type', 'application/json')
            res.send(response);
        });
    });

}
