'use strict';

const
    express = require('express'),
    SwaggerExpress = require('swagger-express-mw'),
    config = require('./config/config'),
    app = express(),
    swaggerConfig = { appRoot: __dirname };

module.exports = app; // for testing

SwaggerExpress.create(swaggerConfig, function(err, swaggerExpress) {
  if(err){ throw err; }

  swaggerExpress.register(app);

  var port = process.env.PORT || config.port;
  app.listen(port);
});
